#!/bin/bash
# ============================================================================
# build_initrd.sh — Build Alpine initramfs with phi-lattice /init
# ============================================================================
#
# Downloads Alpine mini root filesystem, installs busybox+util-linux,
# injects our custom /init, and crams it into a gzip'd cpio archive.
#
# Prerequisites: wget, tar, cpio, gzip (standard Alpine/Debian build tools)
# No Docker. No Python. Produces: bin/hdgl_initrd.img
#
# Usage: bash build_initrd.sh
# ============================================================================

set -e

ALPINE_VER="3.20.3"
ALPINE_ARCH="x86_64"
ALPINE_MINI="alpine-minirootfs-${ALPINE_VER}-${ALPINE_ARCH}.tar.gz"
ALPINE_URL="https://dl-cdn.alpinelinux.org/alpine/v${ALPINE_VER%.*}/releases/${ALPINE_ARCH}/${ALPINE_MINI}"

WORK="$(dirname "$0")/build_initrd_work"
OUTPUT="$(dirname "$0")/bin/hdgl_initrd.img"
INIT_SRC="$(dirname "$0")/alpine_init"

mkdir -p "$WORK" "$(dirname "$0")/bin"

echo "[initrd] Alpine mini root: ${ALPINE_VER}"

# ── Step 1: download mini rootfs ────────────────────────────────────────────
if [ ! -f "${WORK}/${ALPINE_MINI}" ]; then
    echo "[initrd] downloading ${ALPINE_MINI}..."
    wget -q -O "${WORK}/${ALPINE_MINI}" "${ALPINE_URL}"
else
    echo "[initrd] using cached ${ALPINE_MINI}"
fi

# ── Step 2: extract into initrd tree ────────────────────────────────────────
echo "[initrd] extracting mini rootfs..."
rm -rf "${WORK}/initrd"
mkdir -p "${WORK}/initrd"
tar -xzf "${WORK}/${ALPINE_MINI}" -C "${WORK}/initrd"

# ── Step 3: install our /init (replaces Alpine's default) ───────────────────
echo "[initrd] installing phi-lattice /init..."
cp "${INIT_SRC}" "${WORK}/initrd/init"
chmod 755 "${WORK}/initrd/init"

# ── Step 4: ensure switch_root and basic mounts are available ───────────────
# Alpine mini rootfs includes busybox — make sure mount/switch_root are linked
chroot "${WORK}/initrd" /bin/busybox --install -s 2>/dev/null || true

# Ensure /mnt/root exists for the switch_root target
mkdir -p "${WORK}/initrd/mnt/root"

# Ensure /run/lattice mountpoint exists
mkdir -p "${WORK}/initrd/run/lattice"

# ── Step 5: pack into gzip'd cpio ───────────────────────────────────────────
echo "[initrd] packing cpio archive..."
( cd "${WORK}/initrd" && find . | cpio -H newc -o 2>/dev/null ) | gzip -9 > "${OUTPUT}"

SZ=$(stat -c%s "${OUTPUT}")
SECTORS=$(( (SZ + 511) / 512 ))

echo "[initrd] done: ${OUTPUT}"
echo "[initrd] size: ${SZ} bytes = ${SECTORS} sectors"
echo ""
echo "[initrd] to embed into HDGL disk image:"
echo "  dd if=${OUTPUT} of=bin/hdgl_router64.img bs=512 seek=16896 conv=notrunc"
echo ""
echo "[initrd] then at Router64> prompt:"
echo "  alpine 512 16896"
