/*
 * phi_analog_module.c
 *
 * Linux kernel module: /dev/phi0
 *
 * Exposes the HDGL float4096 analog substrate — running concurrently on the
 * secondary CPU core (AP) — to Alpine Linux userspace.
 *
 * WHAT ALPINE SEES:
 *   /dev/phi0         — char device, read() returns phi_substrate_state struct
 *   /sys/phi/d_bits   — 32-bit binary pool (D1..D32, e.g. 0xFFFF0000)
 *   /sys/phi/dn_agg   — 8-nibble Dn aggregate from float4096 fold
 *   /sys/phi/tick     — AP substrate tick count
 *   /sys/phi/psi      — 8 strand ternary polarities
 *   /sys/phi/status   — "TICKING" or "OFFLINE"
 *
 * SHM PROTOCOL:
 *   The HDGL AP writes to physical memory at 0x7000 every float4096 tick.
 *   This module maps that region and exposes it cleanly.
 *   mfence on AP + ioread32 on module side ensures coherency.
 *
 * BUILD (in Alpine initramfs or installed system):
 *   apk add linux-headers alpine-sdk
 *   make -C /lib/modules/$(uname -r)/build M=$(pwd) modules
 *   insmod phi_analog_module.ko
 *
 * NO PYTHON. NO EXTERNAL DEPENDENCIES. Standard kernel module API only.
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/sysfs.h>
#include <linux/kobject.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("StealthMachines / HDGL");
MODULE_DESCRIPTION("HDGL float4096 Analog Substrate Interface");

/* SHM layout (matches hdgl_smp_substrate.asm) */
#define SHM_PHYS_BASE   0x7000UL
#define SHM_SIZE        0x1000UL        /* 4KB — one page */

#define SHM_OFF_MAGIC   0x000           /* u64: 0x48444C535542530 = "HDGLSUBS" */
#define SHM_OFF_STATUS  0x008           /* u32: 0=uninit, 1=ready, 2=ticking */
#define SHM_OFF_TICK    0x00C           /* u32: tick counter */
#define SHM_OFF_DN_AGG  0x010           /* u32: 8-nibble Dn aggregate */
#define SHM_OFF_PSI     0x014           /* 8 × u32: strand ternary polarities */
#define SHM_OFF_D_SLOTS 0x034           /* 32 × f64: D1..D32 float64 projections */
#define SHM_OFF_D_BITS  0x134           /* u32: 32-bit binary pool */
#define SHM_OFF_TSTAMP  0x138           /* u64: rdtsc at last tick */
#define SHM_OFF_F4096   0x140           /* 213 × u64: float4096 sample of m[2048] */

#define SHM_MAGIC_VAL   0x48444C53535542ULL

/* Userspace-readable state struct */
struct phi_substrate_state {
    __u64 magic;
    __u32 status;               /* 0=offline, 1=ready, 2=ticking */
    __u32 tick;
    __u32 dn_aggregate;         /* 8-nibble field fold */
    __s32 strand_psi[8];        /* ternary: -1, 0, +1 per strand */
    __u64 d_slots[32];          /* D1..D32 as IEEE 754 double bits */
    __u32 d_bits;               /* 32-bit binary pool, e.g. 0xFFFF0000 */
    __u64 timestamp_tsc;
    __u64 f4096_sample[213];    /* full float4096 snapshot of m[2048] */
};

/* Module state */
static void __iomem   *shm_virt;
static dev_t           phi_dev;
static struct cdev     phi_cdev;
static struct class   *phi_class;
static struct kobject *phi_kobj;

/* ── SHM read helpers ─────────────────────────────────────────────────────── */

static int phi_shm_valid(void)
{
    u64 magic;
    if (!shm_virt)
        return 0;
    magic = readq(shm_virt + SHM_OFF_MAGIC);
    return (magic == SHM_MAGIC_VAL);
}

static void phi_read_state(struct phi_substrate_state *s)
{
    int i;
    memset(s, 0, sizeof(*s));
    if (!shm_virt)
        return;

    s->magic        = readq(shm_virt + SHM_OFF_MAGIC);
    s->status       = readl(shm_virt + SHM_OFF_STATUS);
    s->tick         = readl(shm_virt + SHM_OFF_TICK);
    s->dn_aggregate = readl(shm_virt + SHM_OFF_DN_AGG);

    for (i = 0; i < 8; i++)
        s->strand_psi[i] = (s32)readl(shm_virt + SHM_OFF_PSI + i * 4);

    for (i = 0; i < 32; i++)
        s->d_slots[i] = readq(shm_virt + SHM_OFF_D_SLOTS + i * 8);

    s->d_bits       = readl(shm_virt + SHM_OFF_D_BITS);
    s->timestamp_tsc = readq(shm_virt + SHM_OFF_TSTAMP);

    for (i = 0; i < 213; i++)
        s->f4096_sample[i] = readq(shm_virt + SHM_OFF_F4096 + i * 8);
}

/* ── /dev/phi0 char device ────────────────────────────────────────────────── */

static int phi_open(struct inode *inode, struct file *filp)
{
    if (!phi_shm_valid())
        return -ENODEV;
    return 0;
}

static ssize_t phi_read(struct file *filp, char __user *buf,
                        size_t count, loff_t *ppos)
{
    struct phi_substrate_state state;
    size_t to_copy;

    if (*ppos >= (loff_t)sizeof(state))
        return 0;

    phi_read_state(&state);

    to_copy = min(count, sizeof(state) - (size_t)*ppos);
    if (copy_to_user(buf, (char *)&state + *ppos, to_copy))
        return -EFAULT;

    *ppos += to_copy;
    return to_copy;
}

static const struct file_operations phi_fops = {
    .owner  = THIS_MODULE,
    .open   = phi_open,
    .read   = phi_read,
};

/* ── sysfs attributes ─────────────────────────────────────────────────────── */

static ssize_t d_bits_show(struct kobject *kobj, struct kobj_attribute *attr,
                            char *buf)
{
    if (!phi_shm_valid())
        return scnprintf(buf, PAGE_SIZE, "OFFLINE\n");
    return scnprintf(buf, PAGE_SIZE, "0x%08X\n",
                     readl(shm_virt + SHM_OFF_D_BITS));
}
static struct kobj_attribute d_bits_attr = __ATTR_RO(d_bits);

static ssize_t dn_agg_show(struct kobject *kobj, struct kobj_attribute *attr,
                            char *buf)
{
    if (!phi_shm_valid())
        return scnprintf(buf, PAGE_SIZE, "OFFLINE\n");
    return scnprintf(buf, PAGE_SIZE, "0x%08X\n",
                     readl(shm_virt + SHM_OFF_DN_AGG));
}
static struct kobj_attribute dn_agg_attr = __ATTR_RO(dn_agg);

static ssize_t tick_show(struct kobject *kobj, struct kobj_attribute *attr,
                          char *buf)
{
    if (!phi_shm_valid())
        return scnprintf(buf, PAGE_SIZE, "OFFLINE\n");
    return scnprintf(buf, PAGE_SIZE, "%u\n",
                     readl(shm_virt + SHM_OFF_TICK));
}
static struct kobj_attribute tick_attr = __ATTR_RO(tick);

static ssize_t psi_show(struct kobject *kobj, struct kobj_attribute *attr,
                         char *buf)
{
    int i, n = 0;
    const char *names = "ABCDEFGH";
    if (!phi_shm_valid())
        return scnprintf(buf, PAGE_SIZE, "OFFLINE\n");
    for (i = 0; i < 8; i++) {
        s32 v = (s32)readl(shm_virt + SHM_OFF_PSI + i * 4);
        n += scnprintf(buf + n, PAGE_SIZE - n, "%c:%+d ", names[i], v);
    }
    n += scnprintf(buf + n, PAGE_SIZE - n, "\n");
    return n;
}
static struct kobj_attribute psi_attr = __ATTR_RO(psi);

static ssize_t status_show(struct kobject *kobj, struct kobj_attribute *attr,
                             char *buf)
{
    u32 s;
    if (!phi_shm_valid())
        return scnprintf(buf, PAGE_SIZE, "OFFLINE\n");
    s = readl(shm_virt + SHM_OFF_STATUS);
    return scnprintf(buf, PAGE_SIZE, "%s\n",
                     s == 2 ? "TICKING" : s == 1 ? "READY" : "OFFLINE");
}
static struct kobj_attribute status_attr = __ATTR_RO(status);

static struct attribute *phi_attrs[] = {
    &d_bits_attr.attr,
    &dn_agg_attr.attr,
    &tick_attr.attr,
    &psi_attr.attr,
    &status_attr.attr,
    NULL,
};

static struct attribute_group phi_attr_group = {
    .attrs = phi_attrs,
};

/* ── Module init / exit ───────────────────────────────────────────────────── */

static int __init phi_module_init(void)
{
    int err;

    /* Map SHM physical region */
    shm_virt = ioremap(SHM_PHYS_BASE, SHM_SIZE);
    if (!shm_virt) {
        pr_err("phi: failed to map SHM at 0x%lx\n", SHM_PHYS_BASE);
        return -ENOMEM;
    }

    /* Verify magic — substrate must be running */
    if (!phi_shm_valid()) {
        pr_warn("phi: SHM magic not found at 0x%lx — "
                "substrate offline or SHM not initialized\n", SHM_PHYS_BASE);
        /* Do not fail: allow load without substrate (status = OFFLINE) */
    } else {
        pr_info("phi: float4096 substrate TICKING — "
                "Dn=0x%08X bits=0x%08X tick=%u\n",
                readl(shm_virt + SHM_OFF_DN_AGG),
                readl(shm_virt + SHM_OFF_D_BITS),
                readl(shm_virt + SHM_OFF_TICK));
    }

    /* Register char device /dev/phi0 */
    err = alloc_chrdev_region(&phi_dev, 0, 1, "phi");
    if (err)
        goto err_unmap;

    cdev_init(&phi_cdev, &phi_fops);
    err = cdev_add(&phi_cdev, phi_dev, 1);
    if (err)
        goto err_unregion;

    phi_class = class_create(THIS_MODULE, "phi");
    if (IS_ERR(phi_class)) {
        err = PTR_ERR(phi_class);
        goto err_cdev;
    }

    device_create(phi_class, NULL, phi_dev, NULL, "phi0");

    /* Create /sys/phi/ attribute group */
    phi_kobj = kobject_create_and_add("phi", kernel_kobj);
    if (!phi_kobj) {
        err = -ENOMEM;
        goto err_device;
    }

    err = sysfs_create_group(phi_kobj, &phi_attr_group);
    if (err)
        goto err_kobj;

    pr_info("phi: /dev/phi0 ready | /sys/phi/{d_bits,dn_agg,tick,psi,status}\n");
    pr_info("phi: read() returns phi_substrate_state (%zu bytes)\n",
            sizeof(struct phi_substrate_state));
    return 0;

err_kobj:
    kobject_put(phi_kobj);
err_device:
    device_destroy(phi_class, phi_dev);
    class_destroy(phi_class);
err_cdev:
    cdev_del(&phi_cdev);
err_unregion:
    unregister_chrdev_region(phi_dev, 1);
err_unmap:
    iounmap(shm_virt);
    return err;
}

static void __exit phi_module_exit(void)
{
    sysfs_remove_group(phi_kobj, &phi_attr_group);
    kobject_put(phi_kobj);
    device_destroy(phi_class, phi_dev);
    class_destroy(phi_class);
    cdev_del(&phi_cdev);
    unregister_chrdev_region(phi_dev, 1);
    if (shm_virt)
        iounmap(shm_virt);
    pr_info("phi: unloaded\n");
}

module_init(phi_module_init);
module_exit(phi_module_exit);
