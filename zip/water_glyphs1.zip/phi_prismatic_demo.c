/*
 * phi_prismatic_demo.c
 *
 * prismatic5y without Python.
 *
 * Reads the live float4096 substrate state from /dev/phi0
 * (via phi_analog_module.ko) and feeds it to the GLSL prismatic shader
 * as uniforms — Dn aggregate, D-slot projections, binary pool — so the
 * rendered field reflects the actual running substrate.
 *
 * The visual is the output of the 8-strand binary pool described in the
 * attached specification: Strand A-H, D1-D32, Omega tensions = 1/φ^(7n).
 *
 * Compile (Alpine):
 *   apk add mesa-dev glew-dev freeglut-dev gcc-g++
 *   gcc -O3 -o phi_prismatic phi_prismatic_demo.c -lGL -lGLEW -lglut -lm
 *
 * Compile (Debian/Ubuntu):
 *   apt install mesa-utils libgl1-mesa-dev libglew-dev freeglut3-dev
 *   gcc -O3 -o phi_prismatic phi_prismatic_demo.c -lGL -lGLEW -lglut -lm
 *
 * No Python. No numpy. No OpenGL GLUT wrappers in Python.
 * Pure C99 + standard OpenGL.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#include <GL/glew.h>
#include <GL/glut.h>

/* ── phi_substrate_state (must match phi_analog_module.c) ────────────────── */
struct phi_substrate_state {
    uint64_t magic;
    uint32_t status;
    uint32_t tick;
    uint32_t dn_aggregate;
    int32_t  strand_psi[8];
    uint64_t d_slots[32];          /* bits of IEEE 754 doubles */
    uint32_t d_bits;
    uint64_t timestamp_tsc;
    uint64_t f4096_sample[213];
};

/* ── Globals ─────────────────────────────────────────────────────────────── */
#define WIN_W 1920
#define WIN_H 1080
#define NUM_SUPER       32768
#define NUM_INSTANCES   4096
#define MAX_SLICE       8
#define PHI             1.6180339887498948f

static GLuint shader_prog, vao, vbo;
static int phi_fd = -1;
static struct phi_substrate_state sub_state;
static float cycle = 0.0f;

static float fib_table[128];
static float prime_table[128];

/* ── Shader sources ──────────────────────────────────────────────────────── */
static const char *vert_src =
    "#version 330\n"
    "in vec2 position;\n"
    "out vec2 texCoord;\n"
    "void main(){\n"
    "    texCoord = 0.5*(position+1.0);\n"
    "    gl_Position = vec4(position, 0.0, 1.0);\n"
    "}\n";

/* Fragment shader: prismatic recursion modulated by live float4096 substrate */
static const char *frag_src =
    "#version 330\n"
    "in vec2 texCoord;\n"
    "out vec4 fragColor;\n"
    "uniform float cycle;\n"
    "uniform float omegaTime;\n"
    "uniform float phi;\n"
    "uniform int instanceID;\n"
    "uniform int NUM_SUPER;\n"
    "uniform int NUM_INSTANCES;\n"
    "uniform float fibTable[128];\n"
    "uniform float primeTable[128];\n"
    "// Live float4096 substrate outputs:\n"
    "uniform float d_slots[32];      // D1..D32 float64 projections from AP\n"
    "uniform float d_bits_f;         // SHM_D_BITS / 4294967295.0 in [0,1]\n"
    "uniform float dn_agg_f;         // Dn aggregate / 4294967295.0\n"
    "\n"
    "float prismatic_recursion(int id, float r){\n"
    "    float phi_harm  = pow(phi, float(mod(id, 16)));\n"
    "    float fib_harm  = fibTable[id % 128];\n"
    "    float dyadic    = float(1 << int(mod(float(id), 16.0)));\n"
    "    float prime_h   = primeTable[id % 128];\n"
    "    float Omega     = 0.5 + 0.5*sin(omegaTime + float(id)*0.01);\n"
    "    // Modulate Omega by live float4096 D-slot from the AP substrate:\n"
    "    // This is the direct connection between the running substrate and the render.\n"
    "    float d_mod = d_slots[id % 32] * 0.001 + 1.0;\n"
    "    float r_dim = pow(r, float(mod(id, 7) + 1));\n"
    "    return sqrt(phi_harm * fib_harm * dyadic * prime_h * Omega * d_mod) * r_dim;\n"
    "}\n"
    "\n"
    "void main(){\n"
    "    float r   = length(texCoord - 0.5) * 2.0;\n"
    "    float val = 0.0;\n"
    "    for(int s = 0; s < NUM_SUPER; s++){\n"
    "        int idx = (instanceID * NUM_SUPER + s) % NUM_INSTANCES;\n"
    "        val += prismatic_recursion(idx, r);\n"
    "    }\n"
    "    val /= float(NUM_SUPER);\n"
    "    // Binary pool (SHM_D_BITS) modulates alpha:\n"
    "    // 0xFFFF0000 → 0.9999 when D13-D32 are all 1\n"
    "    float phase = sin(cycle*0.01 + val);\n"
    "    fragColor = vec4(val, phase, r, d_bits_f);\n"
    "}\n";

/* ── Tables ───────────────────────────────────────────────────────────────── */
static void build_tables(void)
{
    static const int primes[] = {
        2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,
        59,61,67,71,73,79,83,89,97,101,103,107,109,113,127,131
    };
    double phi_d = PHI;
    double fib_a = 1.0, fib_b = 1.0;
    int i;

    for (i = 0; i < 128; i++) {
        double tmp = fib_a + fib_b;
        fib_a = fib_b;
        fib_b = tmp;
        fib_table[i] = (float)fib_a;
        prime_table[i] = (float)primes[i % (sizeof(primes)/sizeof(primes[0]))];
        (void)phi_d;
    }
}

/* ── Shader compile ────────────────────────────────────────────────────────── */
static GLuint compile_shader(GLenum type, const char *src)
{
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, NULL);
    glCompileShader(s);
    GLint ok;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[4096];
        glGetShaderInfoLog(s, sizeof(buf), NULL, buf);
        fprintf(stderr, "shader compile error:\n%s\n", buf);
        exit(1);
    }
    return s;
}

static void init_gl(void)
{
    glewInit();
    GLuint vs = compile_shader(GL_VERTEX_SHADER,   vert_src);
    GLuint fs = compile_shader(GL_FRAGMENT_SHADER, frag_src);
    shader_prog = glCreateProgram();
    glAttachShader(shader_prog, vs);
    glAttachShader(shader_prog, fs);
    glLinkProgram(shader_prog);
    GLint ok;
    glGetProgramiv(shader_prog, GL_LINK_STATUS, &ok);
    if (!ok) {
        char buf[4096];
        glGetProgramInfoLog(shader_prog, sizeof(buf), NULL, buf);
        fprintf(stderr, "program link error:\n%s\n", buf);
        exit(1);
    }

    float verts[] = { -1,-1, 1,-1, -1,1, 1,1 };
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    GLint pos = glGetAttribLocation(shader_prog, "position");
    glEnableVertexAttribArray(pos);
    glVertexAttribPointer(pos, 2, GL_FLOAT, GL_FALSE, 0, NULL);
}

/* ── Substrate read ─────────────────────────────────────────────────────── */
static void read_substrate(void)
{
    if (phi_fd < 0) {
        phi_fd = open("/dev/phi0", O_RDONLY);
        if (phi_fd < 0)
            return; /* no substrate — demo still runs with zero values */
    }
    lseek(phi_fd, 0, SEEK_SET);
    if (read(phi_fd, &sub_state, sizeof(sub_state)) != sizeof(sub_state)) {
        close(phi_fd);
        phi_fd = -1;
    }
}

/* ── Render ──────────────────────────────────────────────────────────────── */
static void display(void)
{
    static int instance_id = 0;

    /* Read live substrate state from AP core every frame */
    read_substrate();

    glClear(GL_COLOR_BUFFER_BIT);
    glUseProgram(shader_prog);

    /* Time */
    glUniform1f(glGetUniformLocation(shader_prog, "cycle"), cycle);
    glUniform1f(glGetUniformLocation(shader_prog, "omegaTime"),
                (float)sub_state.tick * 0.001f);   /* AP tick as time base */

    /* Constants */
    glUniform1f(glGetUniformLocation(shader_prog, "phi"), PHI);
    glUniform1i(glGetUniformLocation(shader_prog, "instanceID"), instance_id);
    glUniform1i(glGetUniformLocation(shader_prog, "NUM_SUPER"), NUM_SUPER);
    glUniform1i(glGetUniformLocation(shader_prog, "NUM_INSTANCES"), NUM_INSTANCES);

    /* Tables */
    glUniform1fv(glGetUniformLocation(shader_prog, "fibTable"),   128, fib_table);
    glUniform1fv(glGetUniformLocation(shader_prog, "primeTable"), 128, prime_table);

    /* Live substrate: D-slot float64 projections */
    float d_slots_f[32];
    for (int i = 0; i < 32; i++) {
        /* Decode IEEE 754 double from u64 bits */
        double v;
        memcpy(&v, &sub_state.d_slots[i], 8);
        d_slots_f[i] = (float)v;
    }
    glUniform1fv(glGetUniformLocation(shader_prog, "d_slots"), 32, d_slots_f);

    /* Binary pool normalized */
    float d_bits_f = (float)(sub_state.d_bits) / 4294967295.0f;
    glUniform1f(glGetUniformLocation(shader_prog, "d_bits_f"), d_bits_f);

    /* Dn aggregate normalized */
    float dn_f = (float)(sub_state.dn_aggregate) / 4294967295.0f;
    glUniform1f(glGetUniformLocation(shader_prog, "dn_agg_f"), dn_f);

    glBindVertexArray(vao);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    glutSwapBuffers();

    /* Advance instance (waterfall across 4096 instances like prismatic5y) */
    instance_id = (instance_id + 1) % NUM_INSTANCES;
    cycle += 1.0f;

    /* Print substrate status to stdout every 256 frames */
    if (((int)cycle & 255) == 0) {
        printf("[phi] tick=%u Dn=0x%08X D_bits=0x%08X status=%u\n",
               sub_state.tick, sub_state.dn_aggregate,
               sub_state.d_bits, sub_state.status);
        fflush(stdout);
    }
}

static void idle(void) { glutPostRedisplay(); }

/* ── Main ────────────────────────────────────────────────────────────────── */
int main(int argc, char **argv)
{
    printf("[phi_prismatic] starting\n");
    printf("  float4096 substrate: /dev/phi0\n");
    printf("  instances: %d  super: %d  phi: %.16f\n",
           NUM_INSTANCES, NUM_SUPER, (double)PHI);

    build_tables();

    /* Open substrate (optional — demo runs without it) */
    phi_fd = open("/dev/phi0", O_RDONLY);
    if (phi_fd < 0) {
        fprintf(stderr, "[phi_prismatic] /dev/phi0 not found "
                "(insmod phi_analog_module.ko first)\n"
                "  running with zero substrate values\n");
    } else {
        read_substrate();
        printf("  substrate status=%u tick=%u Dn=0x%08X bits=0x%08X\n",
               sub_state.status, sub_state.tick,
               sub_state.dn_aggregate, sub_state.d_bits);
    }

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("HDGL Prismatic — float4096 Analog Substrate");

    init_gl();
    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutMainLoop();

    if (phi_fd >= 0) close(phi_fd);
    return 0;
}
