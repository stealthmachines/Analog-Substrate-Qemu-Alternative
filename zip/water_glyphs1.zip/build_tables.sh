#!/bin/bash
# ============================================================================
# build_tables.sh — Build precomputed analog table binaries
# ============================================================================
# Assembles phi_powers_4096.asm, r_dim_4096.asm, and hdgl_float4096.asm
# from the Day 3 source files into binary blobs for embedding in the disk image.
#
# Prerequisites: nasm >= 2.14
# Input files: src/phi_powers_4096.asm, src/r_dim_4096.asm, src/hdgl_float4096.asm
# (Copy from the Day 3 analog_underlay1.zip and analog_underlay2.zip)
#
# Usage: bash build_tables.sh
# Then: dd these into the disk image at the sectors listed.
# ============================================================================
set -e

echo "[tables] Building precomputed analog tables..."

# Assemble phi_powers table (4096 × f64 = 143360 bytes = 280 sectors)
if [ -f src/phi_powers_4096.asm ]; then
    nasm -f bin src/phi_powers_4096.asm -o bin/phi_powers_4096.bin
    echo "[tables] phi_powers_4096.bin: $(stat -c%s bin/phi_powers_4096.bin) bytes ($(( $(stat -c%s bin/phi_powers_4096.bin) / 512 )) sectors)"
else
    echo "[tables] SKIP phi_powers_4096.asm not found in src/ — copy from Day 3 analog_underlay1.zip"
fi

# Assemble r_dim table (4096 × f64 = 143360 bytes = 280 sectors)
if [ -f src/r_dim_4096.asm ]; then
    nasm -f bin src/r_dim_4096.asm -o bin/r_dim_4096.bin
    echo "[tables] r_dim_4096.bin: $(stat -c%s bin/r_dim_4096.bin) bytes ($(( $(stat -c%s bin/r_dim_4096.bin) / 512 )) sectors)"
else
    echo "[tables] SKIP r_dim_4096.asm not found in src/ — copy from Day 3 analog_underlay1.zip"
fi

# Assemble float4096 DNA glyph data (~8KB = 16 sectors)
if [ -f src/hdgl_float4096.asm ]; then
    nasm -f bin src/hdgl_float4096.asm -o bin/hdgl_float4096_data.bin
    echo "[tables] hdgl_float4096_data.bin: $(stat -c%s bin/hdgl_float4096_data.bin) bytes ($(( ($(stat -c%s bin/hdgl_float4096_data.bin) + 511) / 512 )) sectors)"
else
    echo "[tables] SKIP hdgl_float4096.asm not found in src/ — copy from Day 3 analog_underlay2.zip"
fi

# Check if the main disk image exists
if [ ! -f bin/hdgl_router64.img ]; then
    echo "[tables] ERROR: run build.sh first to produce bin/hdgl_router64.img"
    exit 1
fi

# Determine LBAs (after runtime 64 sectors, firmware ~100 sectors = sector ~166)
# Get current image size
IMG_SECTORS=$(( $(stat -c%s bin/hdgl_router64.img) / 512 ))
echo "[tables] Current image: $IMG_SECTORS sectors"

# Find first free sector (round up to next 64-sector boundary for alignment)
PHI_POWERS_LBA=$(( ((IMG_SECTORS + 63) / 64) * 64 ))
R_DIM_LBA=$(( PHI_POWERS_LBA + 280 ))
FLOAT4096_LBA=$(( R_DIM_LBA + 280 ))
ALPINE_KERNEL_LBA=$(( ((FLOAT4096_LBA + 16 + 511) / 512) * 512 ))
ALPINE_INITRD_LBA=$(( ALPINE_KERNEL_LBA + 16384 ))

echo "[tables] LBA assignments:"
echo "  PHI_POWERS_SECTOR  = $PHI_POWERS_LBA"
echo "  R_DIM_SECTOR       = $R_DIM_LBA"
echo "  FLOAT4096_SECTOR   = $FLOAT4096_LBA"
echo "  ALPINE_KERNEL_LBA  = $ALPINE_KERNEL_LBA   (for: alpine $ALPINE_KERNEL_LBA $ALPINE_INITRD_LBA)"
echo "  ALPINE_INITRD_LBA  = $ALPINE_INITRD_LBA"
echo ""
echo "[tables] Update hdgl_analog_processor.hdgl:"
echo "  PHI_POWERS_SECTOR  = $PHI_POWERS_LBA"
echo "  R_DIM_SECTOR       = $R_DIM_LBA"
echo "  FLOAT4096_SECTOR   = $FLOAT4096_LBA"

# Extend image to fit everything
NEEDED=$(( (ALPINE_INITRD_LBA + 8192 + 511) / 512 * 512 * 512 ))
CURR=$(stat -c%s bin/hdgl_router64.img)
if [ "$CURR" -lt "$NEEDED" ]; then
    echo "[tables] Extending image to $NEEDED bytes..."
    dd if=/dev/zero bs=512 count=$(( (NEEDED - CURR) / 512 )) >> bin/hdgl_router64.img 2>/dev/null
fi

# Embed tables
[ -f bin/phi_powers_4096.bin    ] && dd if=bin/phi_powers_4096.bin    of=bin/hdgl_router64.img bs=512 seek=$PHI_POWERS_LBA conv=notrunc 2>/dev/null && echo "[tables] phi_powers embedded at LBA $PHI_POWERS_LBA"
[ -f bin/r_dim_4096.bin         ] && dd if=bin/r_dim_4096.bin         of=bin/hdgl_router64.img bs=512 seek=$R_DIM_LBA      conv=notrunc 2>/dev/null && echo "[tables] r_dim embedded at LBA $R_DIM_LBA"
[ -f bin/hdgl_float4096_data.bin] && dd if=bin/hdgl_float4096_data.bin of=bin/hdgl_router64.img bs=512 seek=$FLOAT4096_LBA  conv=notrunc 2>/dev/null && echo "[tables] float4096 data embedded at LBA $FLOAT4096_LBA"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  NEXT STEPS:"
echo "  1. Update hdgl_analog_processor.hdgl with the LBA assignments above"
echo "  2. Rebuild: bash build.sh"
echo "  3. Re-run build_tables.sh to embed updated tables"
echo "  4. Flash: dd if=bin/hdgl_router64.img of=/dev/sdX bs=512 oflag=sync"
echo "  5. Boot and test: alpine $ALPINE_KERNEL_LBA $ALPINE_INITRD_LBA"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
