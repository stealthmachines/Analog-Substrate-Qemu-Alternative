/* ll_daemon.c — phi-lattice concurrent substrate daemon for Alpine
 *
 * Runs the 8D Kuramoto oscillator seeded from hdgl.dn + hdgl.tick.
 * Writes all 4096 slot values to /lattice/slots/ continuously.
 * Writes /run/lattice/state on every phase transition.
 *
 * Architecture mirrors ll_analog.c (AnaOsc8D, wu-wei phase, phi-seeds)
 * without the Lucas-Lehmer test machinery.  This is the live-running
 * half: the field keeps evolving after Alpine has booted.
 *
 * Build: gcc -O2 -o ll_daemon ll_daemon.c -lm
 * Run:   ll_daemon <dn_hex> <tick_hex> [--slots-dir /lattice/slots]
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/stat.h>

#define ANA_DIMS        8
#define ANA_DT          0.01
#define ANA_PHI         1.6180339887498948
#define ANA_PI          3.14159265358979323846
#define ANA_K_PLUCK     5.0
#define ANA_K_SUSTAIN   3.0
#define ANA_K_FINETUNE  2.0
#define ANA_K_LOCK      1.8
#define ANA_G_PLUCK     0.005
#define ANA_G_SUSTAIN   0.008
#define ANA_G_FINETUNE  0.010
#define ANA_G_LOCK      0.012
#define ANA_CV_SUSTAIN  0.50
#define ANA_CV_FINETUNE 0.30
#define ANA_CV_LOCK     0.05
#define ANA_LOCK_WINDOW 50
#define N_SLOTS         4096
#define PHI32           2654435769U
#define FIB32           2654435761U
#define SQRT_PHI32      2654136499U

typedef enum { PLUCK, SUSTAIN, FINETUNE, LOCK } APhase;

typedef struct {
    double theta[ANA_DIMS];     /* phases */
    double omega[ANA_DIMS];     /* natural frequencies (φ-seeded) */
    double re[ANA_DIMS];        /* complex amplitude real */
    double im[ANA_DIMS];        /* complex amplitude imag */
    double k, gamma;            /* coupling / damping */
    APhase aphase;
    double cv_hist[ANA_LOCK_WINDOW];
    int    cv_pos;
    uint64_t step;
    uint32_t dn;
    uint32_t tick;
} AnaOsc8D;

static volatile int running = 1;
static void on_sigterm(int s) { (void)s; running = 0; }

/* phi_fold: deterministic 32-bit hash → slot value in [0,1] */
static double phi_fold(uint32_t i, uint32_t dn, uint64_t step) {
    uint64_t a = (uint64_t)i * PHI32;
    uint64_t b = (uint64_t)dn * FIB32;
    uint64_t c = (uint64_t)(step & 0xFFFFFFFF) * SQRT_PHI32;
    uint64_t v = (a ^ b ^ c) & 0xFFFFFFFF;
    return (double)v / 4294967295.0;
}

/* seed oscillator from dn+tick (mirrors ll_analog.c BASE_INF_SEEDS approach) */
static void osc_init(AnaOsc8D *o, uint32_t dn, uint32_t tick) {
    o->dn   = dn;
    o->tick = tick;
    o->k     = ANA_K_PLUCK;
    o->gamma = ANA_G_PLUCK;
    o->aphase = PLUCK;
    o->cv_pos = 0;
    o->step   = tick;
    memset(o->cv_hist, 0, sizeof(o->cv_hist));
    for (int i = 0; i < ANA_DIMS; i++) {
        /* φ-seeded natural frequencies */
        o->omega[i] = ANA_PHI * pow(ANA_PHI, (double)i)
                    * (1.0 + phi_fold(i, dn, tick) * 0.1);
        o->theta[i] = phi_fold(i + 100, dn, tick) * 2.0 * ANA_PI;
        o->re[i]    = cos(o->theta[i]);
        o->im[i]    = sin(o->theta[i]);
    }
}

/* one RK4 Kuramoto integration step */
static void osc_step(AnaOsc8D *o) {
    /* mean field R·e^{iΨ} */
    double sum_sin = 0, sum_cos = 0;
    for (int i = 0; i < ANA_DIMS; i++) {
        sum_sin += sin(o->theta[i]);
        sum_cos += cos(o->theta[i]);
    }
    double R   = sqrt(sum_sin*sum_sin + sum_cos*sum_cos) / ANA_DIMS;
    double Psi = atan2(sum_sin, sum_cos);

    /* RK4 */
    double k1[ANA_DIMS], k2[ANA_DIMS], k3[ANA_DIMS], k4[ANA_DIMS];
    for (int i = 0; i < ANA_DIMS; i++) {
        k1[i] = o->omega[i] + o->k * R * sin(Psi - o->theta[i])
               - o->gamma * o->re[i] * sin(o->theta[i]);
    }
    for (int i = 0; i < ANA_DIMS; i++) {
        double t2 = o->theta[i] + k1[i]*ANA_DT*0.5;
        k2[i] = o->omega[i] + o->k * R * sin(Psi - t2);
    }
    for (int i = 0; i < ANA_DIMS; i++) {
        double t3 = o->theta[i] + k2[i]*ANA_DT*0.5;
        k3[i] = o->omega[i] + o->k * R * sin(Psi - t3);
    }
    for (int i = 0; i < ANA_DIMS; i++) {
        double t4 = o->theta[i] + k3[i]*ANA_DT;
        k4[i] = o->omega[i] + o->k * R * sin(Psi - t4);
    }
    for (int i = 0; i < ANA_DIMS; i++) {
        o->theta[i] += (k1[i] + 2*k2[i] + 2*k3[i] + k4[i]) * ANA_DT / 6.0;
        while (o->theta[i] > 2*ANA_PI) o->theta[i] -= 2*ANA_PI;
        while (o->theta[i] < 0)        o->theta[i] += 2*ANA_PI;
        o->re[i] = cos(o->theta[i]);
        o->im[i] = sin(o->theta[i]);
    }

    /* CV for phase detection */
    double cv = 1.0 - R;
    o->cv_hist[o->cv_pos % ANA_LOCK_WINDOW] = cv;
    o->cv_pos++;
    double cv_mean = 0;
    int n = (o->cv_pos < ANA_LOCK_WINDOW) ? o->cv_pos : ANA_LOCK_WINDOW;
    for (int i = 0; i < n; i++) cv_mean += o->cv_hist[i];
    cv_mean /= n;

    /* wu-wei phase transitions */
    switch (o->aphase) {
    case PLUCK:
        if (cv_mean < ANA_CV_SUSTAIN) { o->aphase=SUSTAIN; o->k=ANA_K_SUSTAIN; o->gamma=ANA_G_SUSTAIN; }
        break;
    case SUSTAIN:
        if (cv_mean < ANA_CV_FINETUNE) { o->aphase=FINETUNE; o->k=ANA_K_FINETUNE; o->gamma=ANA_G_FINETUNE; }
        break;
    case FINETUNE:
        if (cv_mean < ANA_CV_LOCK) { o->aphase=LOCK; o->k=ANA_K_LOCK; o->gamma=ANA_G_LOCK; }
        break;
    case LOCK: break;
    }
    o->step++;
}

static const char *phase_name(APhase p) {
    switch (p) {
    case PLUCK:    return "PLUCK";
    case SUSTAIN:  return "SUSTAIN";
    case FINETUNE: return "FINETUNE";
    case LOCK:     return "LOCK";
    default:       return "?";
    }
}

/* write one slot: /lattice/slots/N = float value derived from theta+fold */
static void write_slot(const char *dir, int n, double v) {
    char path[256];
    snprintf(path, sizeof(path), "%s/%d", dir, n);
    FILE *f = fopen(path, "w");
    if (f) { fprintf(f, "%.16f\n", v); fclose(f); }
}

/* write /run/lattice/state */
static void write_state(AnaOsc8D *o, double R, const char *slots_dir) {
    FILE *f = fopen("/run/lattice/state", "w");
    if (!f) return;
    fprintf(f, "LATTICE_N=4096\n");
    fprintf(f, "LATTICE_STEPS=%llu\n", (unsigned long long)o->step);
    fprintf(f, "LATTICE_DN=0x%08X\n", o->dn);
    fprintf(f, "LATTICE_TICK=0x%08X\n", o->tick);
    fprintf(f, "LATTICE_PHASE=%s\n", phase_name(o->aphase));
    fprintf(f, "LATTICE_R=%.6f\n", R);
    fprintf(f, "LATTICE_K=%.3f\n", o->k);
    for (int i = 0; i < ANA_DIMS; i++)
        fprintf(f, "THETA_%d=%.8f\n", i, o->theta[i]);
    fclose(f);
}

int main(int argc, char **argv) {
    uint32_t dn   = 0x88888888;
    uint32_t tick = 0x00000000;
    const char *slots_dir = "/lattice/slots";
    int interval_ms = 100; /* write interval in ms */

    /* parse args: ll_daemon <dn_hex> <tick_hex> [--slots <dir>] [--interval <ms>] */
    for (int i = 1; i < argc; i++) {
        if (i+1 < argc && strcmp(argv[i], "--slots") == 0) {
            slots_dir = argv[++i];
        } else if (i+1 < argc && strcmp(argv[i], "--interval") == 0) {
            interval_ms = atoi(argv[++i]);
        } else if (argv[i][0] != '-') {
            if (dn == 0x88888888 && argv[i][0])
                dn = (uint32_t)strtoul(argv[i], NULL, 16);
            else if (tick == 0x00000000 && argv[i][0])
                tick = (uint32_t)strtoul(argv[i], NULL, 16);
        }
    }

    signal(SIGTERM, on_sigterm);
    signal(SIGINT,  on_sigterm);

    mkdir(slots_dir, 0755);
    mkdir("/run/lattice", 0755);

    AnaOsc8D osc;
    osc_init(&osc, dn, tick);

    fprintf(stderr, "[ll_daemon] dn=0x%08X tick=0x%08X slots=%s\n",
            dn, tick, slots_dir);
    fprintf(stderr, "[ll_daemon] 8D Kuramoto running (Pluck→Sustain→FineTune→Lock)\n");

    APhase last_phase = PLUCK;
    uint64_t write_every = 10; /* write slots every N steps */

    while (running) {
        osc_step(&osc);

        if (osc.step % write_every == 0) {
            /* mean field order parameter */
            double ss=0, sc=0;
            for (int i=0; i<ANA_DIMS; i++) { ss+=sin(osc.theta[i]); sc+=cos(osc.theta[i]); }
            double R = sqrt(ss*ss+sc*sc)/ANA_DIMS;

            /* write 8 primary slots directly from theta values */
            for (int i = 0; i < ANA_DIMS; i++)
                write_slot(slots_dir, i, osc.theta[i] / (2*ANA_PI));

            /* phi-fold remaining slots 8..4095 from step+dn */
            for (int i = ANA_DIMS; i < N_SLOTS; i++)
                write_slot(slots_dir, i, phi_fold(i, dn, osc.step));

            /* write state on phase change or every 100 writes */
            if (osc.aphase != last_phase || (osc.step / write_every) % 100 == 0) {
                write_state(&osc, R, slots_dir);
                if (osc.aphase != last_phase) {
                    fprintf(stderr, "[ll_daemon] step=%llu phase=%s R=%.4f\n",
                            (unsigned long long)osc.step,
                            phase_name(osc.aphase), R);
                    last_phase = osc.aphase;
                }
            }
        }

        /* pace to ~interval_ms per write_every steps */
        struct timespec ts = { 0, (long)(interval_ms * 1000000L / write_every) };
        nanosleep(&ts, NULL);
    }

    fprintf(stderr, "[ll_daemon] stopped at step %llu\n",
            (unsigned long long)osc.step);
    return 0;
}
