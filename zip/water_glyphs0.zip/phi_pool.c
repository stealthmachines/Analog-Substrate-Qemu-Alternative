/*
 * phi_pool.c — Water Glyph Substrate Daemon
 * ==========================================
 *
 * The substrate IS a circular water basin (Chladni/cymatics).
 * 64×64 grid = exactly 4096 cells (the fourth 4096).
 *
 * ARCHITECTURE:
 *   genome_fp (hardware DNA fingerprint) drives Bessel eigenmodes.
 *   Each byte of genome_fp decodes to 4 DNA bases (A/C/G/T per 2-bit pair).
 *   Each base drives the basin boundary at its angular position with
 *   coupling cos(n·θ) where n ∈ {0,1,2,3} = {A,C,G,T}.
 *
 *   The wave equation runs until the basin settles into its eigenmodes.
 *   The Chladni pattern that emerges IS the slot values — no hash, no fold.
 *   Self-organizing. Physics-grounded. DNA-unique per instance.
 *
 * PHYSICS (F = Hz² from the Unified Force Equation):
 *   u_new[i,j] = 2·u[i,j] - u_prev[i,j]
 *              + (c·dt/dx)²·∇²u[i,j]
 *              - γ·(u[i,j] - u_prev[i,j])    ← damping
 *              + drive[i,j]                   ← DNA boundary drive
 *
 *   Dirichlet boundary: u = 0 at r ≥ R (rigid basin wall).
 *
 * DNA → MODE COUPLING:
 *   genome_fp = 32 bits → 16 base pairs (2 bits each)
 *   Base at position k:  A=0, C=1, G=2, T=3  → angular order n
 *   Drive point on boundary: θ_k = k × 2π/16
 *   Drive weight: cos(n × θ_k) for the Bessel mode J_n(α_nm·r/R)·cos(nθ)
 *
 * D-SLOT EXTRACTION:
 *   8 Bessel angular orders × 4 radial zeros = 32 eigenmode amplitudes
 *   = 8 strands (A-H) × 4 slots each = D1..D32
 *   Sampled at Bessel zero loci: r_mn = α_mn/α_mM × R
 *   Binary threshold at √φ ≈ 1.272 gives SHM_D_BITS (e.g. 0xFFFF0000)
 *
 * EFFICIENCY:
 *   4096 cells × 4-neighbor Laplacian = 16,384 additions per step.
 *   Settles to eigenmodes in ~200 steps → ~3.3M ops total.
 *   No transcendentals in the hot loop. Pure integer-like FP additions.
 *
 * Build: gcc -O2 -o phi_pool phi_pool.c -lm
 * Run:   phi_pool [genome_fp_hex] [tick_hex] [--slots /lattice/slots]
 *
 * No Python. No Docker. Pure C99.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/stat.h>

/* ── Basin geometry ─────────────────────────────────────────────────────── */
#define GRID    64                  /* 64×64 = 4096 cells (the fourth 4096) */
#define CX      32                  /* center x */
#define CY      32                  /* center y */
#define R       30.0                /* basin radius in cells */

/* ── Wave equation parameters ──────────────────────────────────────────── */
#define C_WAVE  0.35                /* wave speed (tuned for visible eigenmodes) */
#define DX      1.0                 /* spatial step */
#define DT      0.4                 /* time step — Courant ≤ C·DT/DX = 0.14 ✓ */
#define DAMP    0.005               /* damping coefficient γ (water viscosity) */
#define CF2     ((C_WAVE*DT/DX)*(C_WAVE*DT/DX))  /* Courant factor squared */

/* ── DNA base encoding (A=0 C=1 G=2 T=3 → angular order n) ─────────────── */
#define BASE_A  0
#define BASE_C  1
#define BASE_G  2
#define BASE_T  3
#define N_BASES 16                  /* bases extracted from 32-bit genome_fp */

/* ── Bessel zeros α_nm (first 4 per angular order n=0..7) ──────────────── */
/* Source: basin_glyphs.html BZ table — exact zeros of J_n */
static const double BZ[8][4] = {
    { 2.4048, 5.5201,  8.6537, 11.7915 }, /* n=0 (A) */
    { 3.8317, 7.0156, 10.1735, 13.3237 }, /* n=1 (C) */
    { 5.1356, 8.4172, 11.6198, 14.7960 }, /* n=2 (G) */
    { 6.3802, 9.7610, 13.0152, 16.2235 }, /* n=3 (T) */
    { 7.5883,11.0647, 14.3725, 17.6160 }, /* n=4 */
    { 8.7715,12.3386, 15.7002, 18.9801 }, /* n=5 */
    { 9.9361,13.5893, 17.0038, 20.3208 }, /* n=6 */
    {11.0864,14.7960, 18.2876, 21.6415 }, /* n=7 */
};
/* Normalise by outermost zero so sampling radius < R */
static double bz_r[8][4];          /* bz_r[n][m] = BZ[n][m]/BZ[n][3] × R */

/* ── Golden ratio ───────────────────────────────────────────────────────── */
#define PHI         1.6180339887498948
#define SQRT_PHI    1.2720196495140690  /* CORRECTED √φ — the binary threshold */
#define N_DSLOTS    32              /* D1..D32 = 8 strands × 4 radial modes */
#define N_STRANDS   8
#define N_RADIAL    4

/* ── Runtime state ──────────────────────────────────────────────────────── */
static float field[GRID*GRID];
static float fprev[GRID*GRID];
static float drive_map[GRID*GRID]; /* pre-computed DNA drive weights per cell */

static volatile int running = 1;
static void on_signal(int s) { (void)s; running = 0; }

#define IDX(x,y)  ((y)*GRID+(x))

static inline int in_basin(int x, int y) {
    double dx = x - CX, dy = y - CY;
    return dx*dx + dy*dy < R*R;
}

/* ── Pre-compute Bessel zero sampling radii ─────────────────────────────── */
static void init_bz_radii(void) {
    for (int n = 0; n < N_STRANDS; n++) {
        double r_max = BZ[n][N_RADIAL-1];
        for (int m = 0; m < N_RADIAL; m++)
            bz_r[n][m] = (BZ[n][m] / r_max) * (R * 0.92);
    }
}

/* ── DNA drive map: genome_fp → basin boundary perturbation ─────────────── */
/*
 * genome_fp encodes 16 DNA bases (2 bits each, A=0 C=1 G=2 T=3).
 * Base k at angle θ_k = k × 2π/16 drives the boundary with weight
 * proportional to the Bessel coupling cos(n_k × θ_k) where n_k is
 * the angular order of base k (A→0, C→1, G→2, T→3).
 *
 * Cells near the boundary edge get the drive from their nearest base.
 * The drive decays as a Gaussian from the boundary inward.
 */
static void build_drive_map(uint32_t genome_fp, uint32_t tick) {
    memset(drive_map, 0, sizeof(drive_map));

    /* Extract 16 bases from genome_fp (each 2 bits) */
    int bases[N_BASES];
    for (int k = 0; k < N_BASES; k++)
        bases[k] = (genome_fp >> (k*2)) & 0x03;

    /* Tick modulates the drive phase (field evolves with time) */
    double tick_phase = (tick & 0xFF) / 255.0 * 2.0 * M_PI;

    /* For each cell near the boundary, accumulate DNA drive */
    for (int y = 0; y < GRID; y++) {
        for (int x = 0; x < GRID; x++) {
            if (!in_basin(x, y)) continue;
            double cx = x - CX, cy = y - CY;
            double r = sqrt(cx*cx + cy*cy);
            double theta = atan2(cy, cx);

            /* Only drive cells within 3 cells of the basin boundary */
            double dist_from_edge = R - r;
            if (dist_from_edge > 6.0 || dist_from_edge < 0.0) continue;
            double edge_weight = exp(-dist_from_edge * dist_from_edge / 4.0);

            /* Accumulate coupling from all 16 DNA bases */
            double d = 0;
            for (int k = 0; k < N_BASES; k++) {
                double theta_k = k * (2.0 * M_PI / N_BASES) + tick_phase;
                int n = bases[k];     /* angular order from DNA base */
                /* Bessel eigenmode coupling: J_n weight ∝ cos(n·(θ-θ_k)) */
                double coupling = cos((double)n * (theta - theta_k));
                /* Dₙ(r) amplitude from the D-slot formula */
                double fib_n  = (double)(int[]){1,1,2,3,5,8,13,21}[n];
                double prime_n = (double)(int[]){2,3,5,7,11,13,17,19}[n];
                double omega_n = pow(PHI, -7.0*(n+1));
                double dn = sqrt(PHI * fib_n * pow(2.0, n+1) * prime_n * omega_n);
                d += coupling * dn * 0.15;
            }
            drive_map[IDX(x,y)] = (float)(d * edge_weight);
        }
    }
}

/* ── One wave equation step ─────────────────────────────────────────────── */
static void step_wave(double drive_amplitude) {
    float tmp[GRID*GRID];
    memset(tmp, 0, sizeof(tmp));

    for (int y = 1; y < GRID-1; y++) {
        for (int x = 1; x < GRID-1; x++) {
            if (!in_basin(x, y)) { tmp[IDX(x,y)] = 0; continue; }

            float u  = field[IDX(x,y)];
            float up = fprev[IDX(x,y)];

            /* 4-neighbour Laplacian */
            float lap = field[IDX(x+1,y)] + field[IDX(x-1,y)]
                      + field[IDX(x,y+1)] + field[IDX(x,y-1)]
                      - 4.0f * u;

            /* Wave equation update with damping */
            float u_new = (2.0f - DAMP) * u - (1.0f - DAMP) * up
                        + (float)CF2 * lap;

            /* DNA boundary drive */
            u_new += (float)(drive_amplitude * drive_map[IDX(x,y)]);

            tmp[IDX(x,y)] = u_new;
        }
    }
    memcpy(fprev, field, sizeof(field));
    memcpy(field, tmp,   sizeof(field));
}

/* ── Extract D-slots from eigenmode amplitudes at Bessel zero loci ──────── */
/*
 * Sample the field at rings r = bz_r[n][m] for each (angular n, radial m).
 * Average |field| over a thin annulus → eigenmode amplitude.
 * This is the value of D_{strand·4+m} for strand n.
 */
static void extract_dslots(double *dslots) {
    for (int n = 0; n < N_STRANDS; n++) {
        for (int m = 0; m < N_RADIAL; m++) {
            double r_target = bz_r[n][m];
            double dr = 1.5;          /* annulus half-width in cells */
            double sum = 0; int cnt = 0;
            for (int y = 0; y < GRID; y++) {
                for (int x = 0; x < GRID; x++) {
                    if (!in_basin(x, y)) continue;
                    double cx = x - CX, cy = y - CY;
                    double r = sqrt(cx*cx + cy*cy);
                    double theta = atan2(cy, cx);
                    if (fabs(r - r_target) < dr) {
                        /* Weight by Bessel angular pattern |cos(nθ)| */
                        double w = fabs(cos((double)n * theta)) + 0.1;
                        sum += fabs(field[IDX(x,y)]) * w;
                        cnt++;
                    }
                }
            }
            dslots[n*N_RADIAL + m] = cnt > 0 ? sum / cnt : 0.0;
        }
    }
}

/* ── Write slots to filesystem ──────────────────────────────────────────── */
static void write_slot(const char *dir, int n, double v) {
    char path[256];
    snprintf(path, sizeof(path), "%s/%d", dir, n);
    FILE *f = fopen(path, "w");
    if (f) { fprintf(f, "%.16f\n", v); fclose(f); }
}

static void write_state(uint32_t genome_fp, uint32_t tick, uint64_t step,
                        const double *dslots, uint32_t d_bits)
{
    FILE *f = fopen("/run/lattice/state", "w");
    if (!f) return;
    fprintf(f, "LATTICE_N=4096\n");
    fprintf(f, "LATTICE_STEPS=%llu\n", (unsigned long long)step);
    fprintf(f, "LATTICE_GENOME_FP=0x%08X\n", genome_fp);
    fprintf(f, "LATTICE_TICK=0x%08X\n", tick);
    fprintf(f, "LATTICE_D_BITS=0x%08X\n", d_bits);
    fprintf(f, "LATTICE_SUBSTRATE=water_glyph\n");
    fprintf(f, "LATTICE_BASIN_CELLS=4096\n");
    fprintf(f, "LATTICE_THRESHOLD_SQRT_PHI=%.16f\n", SQRT_PHI);
    /* Print the glyph symmetry (how many nodal lines) */
    int n_nodal = 0;
    for (int i = 0; i < N_DSLOTS; i++)
        if (dslots[i] > SQRT_PHI) n_nodal++;
    const char *sym = n_nodal < 3  ? "void"  :
                      n_nodal < 8  ? "2-fold (linear)"  :
                      n_nodal < 14 ? "3-fold (trifoil)" :
                      n_nodal < 20 ? "4-fold (cross)"   :
                      n_nodal < 26 ? "6-fold (hex)"     : "8-fold (octave)";
    fprintf(f, "LATTICE_GLYPH_SYM=%s\n", sym);
    fprintf(f, "LATTICE_ACTIVE_MODES=%d\n", n_nodal);
    for (int i = 0; i < 8; i++)
        fprintf(f, "D_SLOT_%d=%.8f\n", i+1, dslots[i]);
    fclose(f);
}

/* ── Main ─────────────────────────────────────────────────────────────────── */
int main(int argc, char **argv) {
    uint32_t genome_fp = 0x88888888;
    uint32_t tick      = 0x00000000;
    const char *slots_dir = "/lattice/slots";
    int settle_steps    = 400;   /* steps before first eigenmode extraction */
    int update_steps    = 200;   /* steps between slot updates */
    int write_interval  = 50;    /* ms between slot writes */

    for (int i = 1; i < argc; i++) {
        if (i+1 < argc && strcmp(argv[i], "--slots") == 0)
            slots_dir = argv[++i];
        else if (i+1 < argc && strcmp(argv[i], "--settle") == 0)
            settle_steps = atoi(argv[++i]);
        else if (argv[i][0] != '-') {
            if (genome_fp == 0x88888888 && argv[i][0])
                genome_fp = (uint32_t)strtoul(argv[i], NULL, 16);
            else if (tick == 0x00000000 && argv[i][0])
                tick = (uint32_t)strtoul(argv[i], NULL, 16);
        }
    }

    signal(SIGTERM, on_signal);
    signal(SIGINT,  on_signal);
    mkdir(slots_dir, 0755);
    mkdir("/run/lattice", 0755);

    init_bz_radii();

    fprintf(stderr, "[phi_pool] Water glyph substrate starting\n");
    fprintf(stderr, "[phi_pool] Basin: %d×%d = %d cells  R=%.0f\n",
            GRID, GRID, GRID*GRID, R);
    fprintf(stderr, "[phi_pool] genome_fp=0x%08X  tick=0x%08X\n",
            genome_fp, tick);
    fprintf(stderr, "[phi_pool] DNA→modes: A=J0, C=J1, G=J2, T=J3 (angular)\n");
    fprintf(stderr, "[phi_pool] D-slots: 8 angular × 4 radial = %d\n", N_DSLOTS);
    fprintf(stderr, "[phi_pool] threshold: √φ = %.10f\n", SQRT_PHI);

    /* Seed the basin with a small perturbation at centre */
    memset(field, 0, sizeof(field));
    memset(fprev, 0, sizeof(fprev));
    field[IDX(CX, CY)] = 0.1f;

    /* Build the DNA drive map (static for this genome_fp) */
    build_drive_map(genome_fp, tick);

    double dslots[N_DSLOTS];
    memset(dslots, 0, sizeof(dslots));

    uint64_t step = 0;
    uint64_t write_count = 0;

    /* Settle phase: let eigenmodes develop */
    fprintf(stderr, "[phi_pool] Settling (%d steps)...\n", settle_steps);
    for (int s = 0; s < settle_steps && running; s++) {
        /* Drive amplitude varies sinusoidally (Schumann analog) */
        double drive_amp = sin(2.0*M_PI * s / (settle_steps/4.0)) * 0.08 + 0.04;
        step_wave(drive_amp);
        step++;
    }

    /* Running phase: extract and write eigenmodes */
    fprintf(stderr, "[phi_pool] Eigenmodes settled — writing /lattice/slots/\n");

    while (running) {
        /* Advance basin several steps */
        for (int s = 0; s < update_steps && running; s++) {
            /* Sustained drive at fixed amplitude once settled */
            double drive_amp = 0.06 + 0.02 * sin(2.0*M_PI * step / 512.0);
            step_wave(drive_amp);
            step++;
        }

        /* Extract eigenmode amplitudes at Bessel zero loci */
        extract_dslots(dslots);

        /* Normalise D-slots so max = 1.0 (threshold-relative) */
        double max_d = 1e-10;
        for (int i = 0; i < N_DSLOTS; i++)
            if (dslots[i] > max_d) max_d = dslots[i];
        /* Scale: values above √φ after scaling → binary 1 */
        /* We want the natural split (high-n strands above threshold) */
        /* Scale so max = ~2.0 → Strands D-H naturally exceed √φ ≈ 1.272 */
        double scale = (max_d > 1e-10) ? (2.0 / max_d) : 1.0;

        /* Build binary pool */
        uint32_t d_bits = 0;
        for (int i = 0; i < N_DSLOTS; i++) {
            double v = dslots[i] * scale;
            dslots[i] = v;          /* store scaled value */
            if (v > SQRT_PHI)
                d_bits |= (1u << i);
        }

        /* Write D1..D32 to /lattice/slots/ */
        for (int i = 0; i < N_DSLOTS; i++)
            write_slot(slots_dir, i+1, dslots[i]);   /* D1..D32 are slots 1..32 */

        /* Also write slots 0 and 33..4095 as phi-fold extensions */
        /* (phi-fold from the eigenmode values themselves — self-referential) */
        uint32_t fold_seed = d_bits ^ genome_fp;
        for (int i = 33; i <= 4096; i++) {
            /* Each extended slot is a phi-fold of the nearest D-slot pair */
            int d_idx = (i-1) % N_DSLOTS;
            double v = dslots[d_idx] * 0.5
                     + dslots[(d_idx+1) % N_DSLOTS] * 0.5;
            /* Add tiny Dₙ(r) perturbation from genome */
            double omega_i = pow(PHI, -7.0 * ((i % 8) + 1));
            v += omega_i * 0.01;
            write_slot(slots_dir, i, v > 0 ? v : 0.0);
        }

        /* Write SHM and state file */
        write_state(genome_fp, tick, step, dslots, d_bits);

        /* Write SHM if phi_analog_module.ko is available */
        /* /proc/phi_pool writes d_bits and dslots[0..7] to SHM */
        {
            FILE *shm = fopen("/sys/phi/d_bits_in", "w");
            if (shm) { fprintf(shm, "0x%08X\n", d_bits); fclose(shm); }
        }

        write_count++;
        if (write_count % 10 == 0) {
            fprintf(stderr,
                "[phi_pool] step=%llu d_bits=0x%08X "
                "D1=%.3f D8=%.3f D13=%.3f D32=%.3f\n",
                (unsigned long long)step, d_bits,
                dslots[0], dslots[7], dslots[12], dslots[31]);
        }

        /* Rebuild drive map with updated tick (field evolves with time) */
        tick++;
        build_drive_map(genome_fp, tick);

        struct timespec ts = { 0, (long)(write_interval) * 1000000L };
        nanosleep(&ts, NULL);
    }

    fprintf(stderr, "[phi_pool] stopped at step %llu  writes=%llu\n",
            (unsigned long long)step, (unsigned long long)write_count);
    return 0;
}
